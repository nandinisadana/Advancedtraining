package assignments;

public class Employee {
	int emp_id;  
	String name, address;  

	//Getter and setters for getting and setting properties  
	public int getEmp_id() {  
	  return emp_id;  
	}  
	public void setEmp_id(int emp_id) {  
	  this.emp_id = emp_id;  
	}  
	 
	public String getName() {  
	  return name;  
	}  
	public void setName(String name) {  
	  this.name = name;  
	}  
	public String getAddress() {  
	  return address;  
	}  
	public void setAddress(String address) {  
	  this.address = address;  
	}
	@Override
	public String toString() {
		return "EmployeeDetails [emp_id=" + emp_id + ", name=" + name + ", address=" + address + "]";
	}  

	    
	
	
	  public static void main(String args[]) {  
	        
	      //Creating object of EmployeeDetails class  
	      Employee emp = new Employee();  
	      //Setting values to the properties  
	      emp.setEmp_id(2233);  
	      emp.setName("ravi");  
	      emp.setAddress("chittoor"); 
	      System.out.println(emp); 
	      emp.setEmp_id(2234);  
	      emp.setName("Shayam");  
	      emp.setAddress("tirupati"); 
	      System.out.println(emp);  
	        
	        
	  }  
	}