package assignment;

import java.util.Scanner;

public class TestBook {

	public static void main(String[] args) {
       Scanner scan=new Scanner(System.in);
        
        System.out.println("Enter the Book name:");
        String bookname=scan.nextLine();
        
        System.out.println("Enter the price:");
        int price=scan.nextInt();
        scan.nextLine();
        
        
        Book obj=new Book();
        obj.setBookName(bookname);
        obj.setBookPrice(price);
        System.out.println("Book Details");
        System.out.println("Book Name :"+obj.getBookName());
        System.out.println("Book Price :"+obj.getBookPrice());
       
    }
}

